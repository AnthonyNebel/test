
spool cbo_test.txt
@cbo_test.sql
spool off



