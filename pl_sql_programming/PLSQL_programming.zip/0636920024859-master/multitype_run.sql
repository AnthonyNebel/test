
spool multitype_test.txt

@multitype_query.sql
@multitype_test.sql

spool off



