
DROP PACKAGE stocks_pkg;
DROP TABLE parallel_options_test;

