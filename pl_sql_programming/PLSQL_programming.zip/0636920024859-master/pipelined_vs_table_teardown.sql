
DROP TABLE pipelined_vs_table_tests;
DROP FUNCTION mem;
DROP FUNCTION pipelined_function;
DROP FUNCTION table_function;
DROP TYPE varchar2_ntt;


