
DROP TABLE employees;
DROP TABLE departments;
DROP FUNCTION pipe_employees;
DROP TYPE pipelined_stats_ot;
DROP TYPE employee_ntt;
DROP TYPE employee_ot;

