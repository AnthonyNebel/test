
DROP PACKAGE unload_pkg;
DROP TYPE unload_ntt;
DROP TYPE unload_ot;
DROP DIRECTORY dir;
PROMPT Now go and delete the unloaded flat-files...
